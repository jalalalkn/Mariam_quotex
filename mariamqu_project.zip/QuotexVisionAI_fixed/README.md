# QuotexVisionAI

Android project skeleton for a screen-vision trading assistant.

Important:
- This package includes a `gradlew` launcher so Codemagic can run `./gradlew assembleDebug`.
- It is a lightweight launcher that expects `gradle` to exist in the build environment.
- If you move this into Android Studio, replace it with a full standard Gradle Wrapper for long-term use.

Contains:
- MainActivity
- ScreenCaptureService placeholder
- Analysis engine skeleton
- 10 strategy placeholders
- Self-learning skeleton
- Basic UI layout
