package com.vision.quotexai

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.vision.quotexai.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.txtStatus.text = "Quotex Vision AI Ready"
        binding.txtSignal.text = "Signal: WAIT"
    }
}
