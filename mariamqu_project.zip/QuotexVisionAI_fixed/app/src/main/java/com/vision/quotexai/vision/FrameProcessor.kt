package com.vision.quotexai.vision

class FrameProcessor
