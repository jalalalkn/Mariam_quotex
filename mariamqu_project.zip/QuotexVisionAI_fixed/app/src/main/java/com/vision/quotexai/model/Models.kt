package com.vision.quotexai.model

data class Candle(
    val open: Float,
    val close: Float,
    val high: Float,
    val low: Float,
    val volume: Float = 0f
)

enum class SignalType { UP, DOWN, WAIT }

data class StrategyResult(
    val signal: SignalType,
    val confidence: Float
)
