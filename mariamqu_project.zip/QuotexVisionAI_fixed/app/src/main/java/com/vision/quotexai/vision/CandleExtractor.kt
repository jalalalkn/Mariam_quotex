package com.vision.quotexai.vision

class CandleExtractor
