package com.vision.quotexai.analysis

import com.vision.quotexai.model.SignalType
import com.vision.quotexai.model.StrategyResult

class SelfLearningEngine {

    fun applyWeights(results: List<StrategyResult>): SignalType {
        var score = 0f
        results.forEach {
            when (it.signal) {
                SignalType.UP -> score += it.confidence
                SignalType.DOWN -> score -= it.confidence
                else -> Unit
            }
        }
        return when {
            score > 1f -> SignalType.UP
            score < -1f -> SignalType.DOWN
            else -> SignalType.WAIT
        }
    }
}
