package com.vision.quotexai.analysis

import com.vision.quotexai.model.Candle
import com.vision.quotexai.model.SignalType

class SignalEngine {
    private val strategies = Strategies()
    private val learning = SelfLearningEngine()

    fun analyze(candles: List<Candle>): SignalType {
        val results = strategies.runAll(candles)
        return learning.applyWeights(results)
    }
}
